﻿using System;

namespace _2023._01._03_Delegate
{
    public class Program
    {
        static void Main(string[] args)
        {
            Class1 dele = new Class1();

            dele.Hi();
        }
    }
}