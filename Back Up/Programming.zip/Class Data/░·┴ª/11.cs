﻿using System;

namespace 과제_유혁진_20221227.cs
{
	class MyClass
	{
		static void Main(string[] args)
		{

		}
	}
}